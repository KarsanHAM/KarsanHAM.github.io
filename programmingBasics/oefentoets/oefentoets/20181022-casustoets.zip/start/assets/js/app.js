window.addEventListener('load', init);

function init() {
    console.log('DOM is loaded');
}